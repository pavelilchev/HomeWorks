Auto shop Web site
0. All users can visit home page and find shop location on google map
1. All user can read reviews
2. All users can shedule an appointment 
(shop manager has a email notification when appointment is shedued)
3. Register users can leave a review
4. Admin can search appointments by criteria and can confirm appointment
5. Admin can full controll over eviews - edit, delete, unpublish